using Terraria.ModLoader;

namespace testmod
{
	public class testmod : Mod
	{
	}
}